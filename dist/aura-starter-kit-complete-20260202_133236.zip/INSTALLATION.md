# 🚀 Aura Starter Kit - Installation Instructions

## 📦 What's Included

This bundle contains:
- **Theme**: Aura WP Elementor Starter Theme
- **Plugin**: Aura Site Bootstrapper Plugin

## 🔧 Installation Steps

### 1. Install Theme
1. Go to WordPress Admin → **Appearance → Themes**
2. Click **Add New → Upload Theme**
3. Upload the theme ZIP file from the `theme/` folder
4. **Activate** the theme

### 2. Install Plugin
1. Go to WordPress Admin → **Plugins → Add New**
2. Click **Upload Plugin**
3. Upload the plugin ZIP file from the `plugin/` folder
4. **Activate** the plugin

### 3. Configure
1. Go to **Aura Bootstrapper** in WordPress Admin
2. Click **Setup Site** to automatically create pages and menus
3. Configure your business information
4. Import Elementor templates

## 📋 Requirements

- WordPress 5.0+
- PHP 7.4+
- Elementor Plugin (auto-installed by plugin)

## 🆘 Support

- Documentation: README.md
- Contact: https://agenciaaura.mx

---
**Developed by Aura Marketing**
